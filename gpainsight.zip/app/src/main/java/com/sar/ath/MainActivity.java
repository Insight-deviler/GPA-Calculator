package com.sar.ath;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.ScrollView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import java.text.DecimalFormat;

public class MainActivity extends Activity {
	
	
	private double sum = 0;
	private double num1 = 0;
	private double num2 = 0;
	private double s2 = 0;
	private double num4 = 0;
	private double num5 = 0;
	private double s3 = 0;
	private double num6 = 0;
	private double num7 = 0;
	private double s4 = 0;
	private double num8 = 0;
	private double num9 = 0;
	private double s5 = 0;
	private double num10 = 0;
	private double num11 = 0;
	private double s6 = 0;
	private double num12 = 0;
	private double num13 = 0;
	private double s7 = 0;
	private double num14 = 0;
	private double num15 = 0;
	private double s8 = 0;
	private double num16 = 0;
	private double num17 = 0;
	private double s9 = 0;
	private double num18 = 0;
	private double num19 = 0;
	private double s10 = 0;
	private double num20 = 0;
	private double num21 = 0;
	private double s11 = 0;
	private double num22 = 0;
	private double num23 = 0;
	private double s12 = 0;
	private double num24 = 0;
	private double num25 = 0;
	private String package_name = "";
	private String your_version = "";
	private HashMap<String, Object> map = new HashMap<>();
	private String latest_version = "";
	
	private ArrayList<HashMap<String, Object>> map1 = new ArrayList<>();
	
	private ScrollView scroll1;
	private EditText edittext25;
	private LinearLayout linear17;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private LinearLayout linear11;
	private LinearLayout linear12;
	private LinearLayout linear14;
	private LinearLayout linear13;
	private LinearLayout linear21;
	private LinearLayout linear22;
	private LinearLayout linear24;
	private LinearLayout linear26;
	private EditText p1;
	private TextView textview1;
	private EditText c1;
	private TextView textview14;
	private TextView a;
	private EditText p2;
	private TextView textview2;
	private EditText c2;
	private TextView textview15;
	private TextView b;
	private EditText p3;
	private TextView textview3;
	private EditText c3;
	private TextView textview16;
	private TextView c;
	private EditText p4;
	private TextView textview4;
	private EditText c4;
	private TextView textview17;
	private TextView d;
	private EditText p5;
	private TextView textview5;
	private EditText c5;
	private TextView textview18;
	private TextView e;
	private EditText p6;
	private TextView textview6;
	private EditText c6;
	private TextView textview19;
	private TextView f;
	private EditText p7;
	private TextView textview7;
	private EditText c7;
	private TextView textview20;
	private TextView g;
	private EditText p8;
	private TextView textview8;
	private EditText c8;
	private TextView textview21;
	private TextView h;
	private EditText p9;
	private TextView textview9;
	private EditText c9;
	private TextView textview22;
	private TextView i;
	private EditText p10;
	private TextView textview11;
	private EditText c10;
	private TextView textview24;
	private TextView k;
	private EditText p11;
	private TextView textview10;
	private EditText c11;
	private TextView textview23;
	private TextView j;
	private EditText p12;
	private TextView textview28;
	private EditText c12;
	private TextView textview29;
	private TextView l;
	private Button calculator;
	private TextView textview31;
	private TextView textview32;
	private TextView textview33;
	private TextView m;
	private TextView n;
	private TextView total;
	private TextView textview35;
	private TextView credit;
	private TextView textview37;
	private TextView gpa;
	private Button clear;
	
	private Intent il = new Intent();
	private AlertDialog.Builder update;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		scroll1 = (ScrollView) findViewById(R.id.scroll1);
		edittext25 = (EditText) findViewById(R.id.edittext25);
		linear17 = (LinearLayout) findViewById(R.id.linear17);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		linear21 = (LinearLayout) findViewById(R.id.linear21);
		linear22 = (LinearLayout) findViewById(R.id.linear22);
		linear24 = (LinearLayout) findViewById(R.id.linear24);
		linear26 = (LinearLayout) findViewById(R.id.linear26);
		p1 = (EditText) findViewById(R.id.p1);
		textview1 = (TextView) findViewById(R.id.textview1);
		c1 = (EditText) findViewById(R.id.c1);
		textview14 = (TextView) findViewById(R.id.textview14);
		a = (TextView) findViewById(R.id.a);
		p2 = (EditText) findViewById(R.id.p2);
		textview2 = (TextView) findViewById(R.id.textview2);
		c2 = (EditText) findViewById(R.id.c2);
		textview15 = (TextView) findViewById(R.id.textview15);
		b = (TextView) findViewById(R.id.b);
		p3 = (EditText) findViewById(R.id.p3);
		textview3 = (TextView) findViewById(R.id.textview3);
		c3 = (EditText) findViewById(R.id.c3);
		textview16 = (TextView) findViewById(R.id.textview16);
		c = (TextView) findViewById(R.id.c);
		p4 = (EditText) findViewById(R.id.p4);
		textview4 = (TextView) findViewById(R.id.textview4);
		c4 = (EditText) findViewById(R.id.c4);
		textview17 = (TextView) findViewById(R.id.textview17);
		d = (TextView) findViewById(R.id.d);
		p5 = (EditText) findViewById(R.id.p5);
		textview5 = (TextView) findViewById(R.id.textview5);
		c5 = (EditText) findViewById(R.id.c5);
		textview18 = (TextView) findViewById(R.id.textview18);
		e = (TextView) findViewById(R.id.e);
		p6 = (EditText) findViewById(R.id.p6);
		textview6 = (TextView) findViewById(R.id.textview6);
		c6 = (EditText) findViewById(R.id.c6);
		textview19 = (TextView) findViewById(R.id.textview19);
		f = (TextView) findViewById(R.id.f);
		p7 = (EditText) findViewById(R.id.p7);
		textview7 = (TextView) findViewById(R.id.textview7);
		c7 = (EditText) findViewById(R.id.c7);
		textview20 = (TextView) findViewById(R.id.textview20);
		g = (TextView) findViewById(R.id.g);
		p8 = (EditText) findViewById(R.id.p8);
		textview8 = (TextView) findViewById(R.id.textview8);
		c8 = (EditText) findViewById(R.id.c8);
		textview21 = (TextView) findViewById(R.id.textview21);
		h = (TextView) findViewById(R.id.h);
		p9 = (EditText) findViewById(R.id.p9);
		textview9 = (TextView) findViewById(R.id.textview9);
		c9 = (EditText) findViewById(R.id.c9);
		textview22 = (TextView) findViewById(R.id.textview22);
		i = (TextView) findViewById(R.id.i);
		p10 = (EditText) findViewById(R.id.p10);
		textview11 = (TextView) findViewById(R.id.textview11);
		c10 = (EditText) findViewById(R.id.c10);
		textview24 = (TextView) findViewById(R.id.textview24);
		k = (TextView) findViewById(R.id.k);
		p11 = (EditText) findViewById(R.id.p11);
		textview10 = (TextView) findViewById(R.id.textview10);
		c11 = (EditText) findViewById(R.id.c11);
		textview23 = (TextView) findViewById(R.id.textview23);
		j = (TextView) findViewById(R.id.j);
		p12 = (EditText) findViewById(R.id.p12);
		textview28 = (TextView) findViewById(R.id.textview28);
		c12 = (EditText) findViewById(R.id.c12);
		textview29 = (TextView) findViewById(R.id.textview29);
		l = (TextView) findViewById(R.id.l);
		calculator = (Button) findViewById(R.id.calculator);
		textview31 = (TextView) findViewById(R.id.textview31);
		textview32 = (TextView) findViewById(R.id.textview32);
		textview33 = (TextView) findViewById(R.id.textview33);
		m = (TextView) findViewById(R.id.m);
		n = (TextView) findViewById(R.id.n);
		total = (TextView) findViewById(R.id.total);
		textview35 = (TextView) findViewById(R.id.textview35);
		credit = (TextView) findViewById(R.id.credit);
		textview37 = (TextView) findViewById(R.id.textview37);
		gpa = (TextView) findViewById(R.id.gpa);
		clear = (Button) findViewById(R.id.clear);
		update = new AlertDialog.Builder(this);
		
		p1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < p1.getText().toString().length()) {
					num1 = Double.parseDouble(p1.getText().toString());
					_compute();
				}
				else {
					num1 = 0;
					_compute();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		c1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < c1.getText().toString().length()) {
					num2 = Double.parseDouble(c1.getText().toString());
					_compute();
				}
				else {
					num2 = 0;
					_compute();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		p2.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < p2.getText().toString().length()) {
					num4 = Double.parseDouble(p2.getText().toString());
					_sum2();
				}
				else {
					num4 = 0;
					_sum2();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		c2.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < c2.getText().toString().length()) {
					num5 = Double.parseDouble(c2.getText().toString());
					_sum2();
				}
				else {
					num5 = 0;
					_sum2();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		p3.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < p3.getText().toString().length()) {
					num6 = Double.parseDouble(p3.getText().toString());
					_sum3();
				}
				else {
					num6 = 0;
					_sum3();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		c3.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < c3.getText().toString().length()) {
					num7 = Double.parseDouble(c3.getText().toString());
					_sum3();
				}
				else {
					num7 = 0;
					_sum3();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		p4.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < p4.getText().toString().length()) {
					num8 = Double.parseDouble(p4.getText().toString());
					_sum4();
				}
				else {
					num8 = 0;
					_sum4();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		c4.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < c4.getText().toString().length()) {
					num9 = Double.parseDouble(c4.getText().toString());
					_sum4();
				}
				else {
					num9 = 0;
					_sum4();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		p5.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < p5.getText().toString().length()) {
					num10 = Double.parseDouble(p5.getText().toString());
					_sum5();
				}
				else {
					num10 = 0;
					_sum5();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		c5.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < c5.getText().toString().length()) {
					num11 = Double.parseDouble(c5.getText().toString());
					_sum5();
				}
				else {
					num11 = 0;
					_sum5();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		p6.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < p6.getText().toString().length()) {
					num12 = Double.parseDouble(p6.getText().toString());
					_sum6();
				}
				else {
					num12 = 0;
					_sum6();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		c6.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < c6.getText().toString().length()) {
					num13 = Double.parseDouble(c6.getText().toString());
					_sum6();
				}
				else {
					num13 = 0;
					_sum6();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		p7.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < p7.getText().toString().length()) {
					num14 = Double.parseDouble(p7.getText().toString());
				}
				else {
					num14 = 0;
				}
				_sum7();
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		c7.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < c7.getText().toString().length()) {
					num15 = Double.parseDouble(c7.getText().toString());
					_sum7();
				}
				else {
					num15 = 0;
					_sum7();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		p8.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < p8.getText().toString().length()) {
					num16 = Double.parseDouble(p8.getText().toString());
					_sum8();
				}
				else {
					num16 = 0;
					_sum8();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		c8.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < c8.getText().toString().length()) {
					num17 = Double.parseDouble(c8.getText().toString());
					_sum8();
				}
				else {
					num17 = 0;
					_sum8();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		p9.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < p9.getText().toString().length()) {
					num18 = Double.parseDouble(p9.getText().toString());
					_sum9();
				}
				else {
					num19 = 0;
					_sum9();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		c9.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < c9.getText().toString().length()) {
					num19 = Double.parseDouble(c9.getText().toString());
					_sum9();
				}
				else {
					num19 = 0;
					_sum9();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		p10.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < p10.getText().toString().length()) {
					num20 = Double.parseDouble(p10.getText().toString());
					_sum10();
				}
				else {
					num20 = 0;
					_sum10();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		c10.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < c10.getText().toString().length()) {
					num21 = Double.parseDouble(c10.getText().toString());
					_sum10();
				}
				else {
					num21 = 0;
					_sum10();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		p11.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < p11.getText().toString().length()) {
					num22 = Double.parseDouble(p11.getText().toString());
					_sum11();
				}
				else {
					num22 = 0;
					_sum11();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		c11.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < c11.getText().toString().length()) {
					num23 = Double.parseDouble(c11.getText().toString());
					_sum11();
				}
				else {
					num23 = 0;
					_sum11();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		p12.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < p12.getText().toString().length()) {
					num24 = Double.parseDouble(p12.getText().toString());
					_sum12();
				}
				else {
					num24 = 0;
					_sum12();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		c12.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < c12.getText().toString().length()) {
					num25 = Double.parseDouble(c12.getText().toString());
					_sum12();
				}
				else {
					num25 = 0;
					_sum12();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		calculator.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				n.setText(String.valueOf((((Double.parseDouble(a.getText().toString()) + Double.parseDouble(b.getText().toString())) + (Double.parseDouble(c.getText().toString()) + Double.parseDouble(d.getText().toString()))) + ((Double.parseDouble(e.getText().toString()) + Double.parseDouble(f.getText().toString())) + (Double.parseDouble(g.getText().toString()) + Double.parseDouble(h.getText().toString())))) + ((Double.parseDouble(i.getText().toString()) + Double.parseDouble(k.getText().toString())) + (Double.parseDouble(j.getText().toString()) + Double.parseDouble(l.getText().toString())))));
				credit.setText(String.valueOf(0 + (((Double.parseDouble(c1.getText().toString()) + Double.parseDouble(c2.getText().toString())) + ((Double.parseDouble(c3.getText().toString()) + Double.parseDouble(c4.getText().toString())) + (Double.parseDouble(c5.getText().toString()) + Double.parseDouble(c6.getText().toString())))) + ((Double.parseDouble(c7.getText().toString()) + Double.parseDouble(c8.getText().toString())) + (Double.parseDouble(c9.getText().toString()) + (Double.parseDouble(c10.getText().toString()) + (Double.parseDouble(c11.getText().toString()) + Double.parseDouble(c12.getText().toString()))))))));
				total.setText(n.getText().toString());
				gpa.setText(String.valueOf(Double.parseDouble(n.getText().toString()) / Double.parseDouble(credit.getText().toString())));
			}
		});
		
		clear.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				a.setText("");
				b.setText("");
				c.setText("");
				d.setText("");
				e.setText("");
				f.setText("");
				g.setText("");
				h.setText("");
				i.setText("");
				k.setText("");
				j.setText("");
				l.setText("");
				n.setText("");
				p2.setText("");
				c2.setText("");
				c3.setText("");
				p3.setText("");
				p4.setText("");
				c4.setText("");
				p5.setText("");
				c5.setText("");
				p6.setText("");
				c6.setText("");
				p7.setText("");
				c7.setText("");
				p8.setText("");
				c8.setText("0");
				p9.setText("");
				c9.setText("0");
				p10.setText("");
				c10.setText("0");
				p11.setText("");
				c11.setText("0");
				p12.setText("");
				c12.setText("0");
				p1.setText("");
				c1.setText("");
				n.setText("");
				credit.setText("Credit");
				total.setText("Total");
				gpa.setText("GPA");
			}
		});
	}
	private void initializeLogic() {
		c8.setText("0");
		c9.setText("0");
		c10.setText("0");
		c11.setText("0");
		c12.setText("0");
		SketchwareUtil.showMessage(getApplicationContext(), "Welcome");
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _compute () {
		sum = num1 * num2;
		a.setText(String.valueOf(sum));
	}
	
	
	private void _sum2 () {
		s2 = num4 * num5;
		b.setText(String.valueOf(s2));
	}
	
	
	private void _sum3 () {
		s3 = num6 * num7;
		c.setText(String.valueOf(s3));
	}
	
	
	private void _sum4 () {
		s4 = num8 * num9;
		d.setText(String.valueOf(s4));
	}
	
	
	private void _sum5 () {
		s5 = num10 * num11;
		e.setText(String.valueOf(s5));
	}
	
	
	private void _sum6 () {
		s6 = num12 * num13;
		f.setText(String.valueOf(s6));
	}
	
	
	private void _sum7 () {
		s7 = num14 * num15;
		g.setText(String.valueOf(s7));
	}
	
	
	private void _sum8 () {
		s8 = num16 * num17;
		h.setText(String.valueOf(s8));
	}
	
	
	private void _sum9 () {
		s9 = num18 * num19;
		i.setText(String.valueOf(s9));
	}
	
	
	private void _sum10 () {
		s10 = num20 * num21;
		k.setText(String.valueOf(s10));
	}
	
	
	private void _sum11 () {
		s11 = num22 * num23;
		j.setText(String.valueOf(s11));
	}
	
	
	private void _sum12 () {
		s12 = num24 * num25;
		l.setText(String.valueOf(s12));
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
